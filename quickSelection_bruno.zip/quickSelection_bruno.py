#################################
# Voce deve um babao pro Bruno ##
#################################

import maya.cmds as cmds
import maya.mel as mel

ver = int(cmds.about(version=1))
print(ver)
if (ver >= 2017 ) :
    from PySide2 import QtGui
    print ("Pyside loaded")
else:
    from PySide import QtGui

from functools import partial


#init

class QuickSelection:

    def __init__(self):

        self.current_character = cmds.optionVar(q="ahCurrentCharacter")
        self.mainWin = "animation_helpers_window"
        self.storeNode = "animationHelpers_QuickSelection_Data"
        self.tittle = "Quick Selection"
        self.orderAttr = "list_order"
        self.btPrefix = "BT_QS_"
        self.uiScrollContainer = "QS_scrollList"
        self.uiMainContainer = "QS_scrollList_main_container"
        self.uiMainRow = "_QS_scrollList_main_row"
        self.uiScrollSlot = "QS_scrollList_slot"
        self.uiScrollTab = "QS_scrollList_tab"
        self.currentColor = [0.366116792,0.5949367285,0.1581477225]
        self.characterNameField = "QS_input_character_name"
        self.buttonNameField = "QS_input_selection_name"
        self.uiButtonTypeContainer ="QS_buttonType_container"
        self.contentWidth = 0

        self.declareUIColors()

        #query cursor attributes
        self.queryCursorPos()

        self.dummyNode(self.storeNode)

        if not cmds.objExists (self.storeNode + "." + self.orderAttr):
            cmds.addAttr(self.storeNode , ln = self.orderAttr, h=False, dt="string")
            cmds.setAttr(self.storeNode + "." + self.orderAttr, "" , type="string")

        self.version = int(cmds.about(version=1))
        
        self.Top = 0
        self.Left = 0
        

        #self.setCurrCharacterFirstTime()

    def checkOS(self):
        sys=""
        checkOs = cmds.about(os=True)

        if checkOs == "mac":

            # IF MAC - escreve o comando para abrir o finder
            sys = "mac"

        elif checkOs == "nt" or checkOs == "win64":

            sys = "win"

        return sys


    ############
    ### UIs ####
    ############

    def scriptJobToReload(self,*args):
        cmds.scriptJob(event=["SceneOpened",partial(self.uiQuickSelection)],p=self.mainWin)

    def toggleWin(self,simpleMode):

        self.queryCursorPos()
        #cmds.evalDeferred(partial(self.reposWin))


        self.simpleMode = simpleMode

        if not cmds.window(self.mainWin,q=1,ex=1):
            self.uiQuickSelection()

            if self.checkMissingNS():
                self.fixNameSpaceUI(missing=1,attr=">>all<<")

        else:
            cmds.deleteUI(self.mainWin)

        self.reposWin



    def uiQuickSelection(self,*args):

        if cmds.window(self.mainWin,q=1,ex=1):
            cmds.deleteUI(self.mainWin)

        cmds.window(self.mainWin,bgc=self.UIColors["bgGrey"],rtf=True,tlb=1,tb=0,w=10,h=10,s=0,t=self.tittle)
        cmds.setFocus(self.mainWin)

        #scriptjob to reloaded
        self.scriptJobToReload()

        #win layout container
        cmds.columnLayout(self.uiMainContainer , bgc=self.UIColors["bgGrey"])

        if not self.simpleMode:
            self.uiNewSelection(self.uiMainContainer)
            cmds.separator(h=5,p=self.uiMainContainer)

        self.createSelectScroll(parent=self.uiMainContainer)

        cmds.showWindow( self.mainWin )

        
    def uiNewSelection(self,parent):
        #main container
        ah_QS_newselection_ui_container = cmds.columnLayout(h=40,bgc=self.UIColors["bgGrey"], p=parent)

        #scroll container
        ah_QS_newselection_ui_row_01 = cmds.rowLayout(h=25, numberOfColumns=6, columnWidth4=[20,100,100,100], columnAlign2=["left","left"], bgc= self.UIColors["bgGrey"])

        #01 button create
        cmds.button(h=20,w=20,ann="create new quick selection", label=" + ", c=partial(self.new),bgc=self.UIColors["bgGreen"])

        if (self.version < 2014 ) :
            #02 character field
            cmds.textField( self.characterNameField ,h=20,w=100, tx="character name",aie=True, ec = partial(self.jumpToSelectionNameField))
            #03 button name field
            cmds.textField( self.buttonNameField ,h=20,w=100, tx="button name",aie=True,ec=partial(self.new),rfc=partial(self.buttonNameFieldReceiveFocus))
        else:
            #02 character field
            cmds.textField( self.characterNameField ,h=20,w=100, pht="character name",aie=True, ec = partial(self.jumpToSelectionNameField))
            #03 button name field
            cmds.textField( self.buttonNameField ,h=20,w=100, pht="button name",aie=True,ec=partial(self.new),rfc=partial(self.buttonNameFieldReceiveFocus))


        #04 button type (radio)
        cmds.rowColumnLayout(h=22, numberOfColumns=2, columnWidth=[(1, 65), (2, 60)], cal=[(1,"left"), (2,"left")], bgc=self.UIColors["bgGrey"],p=ah_QS_newselection_ui_row_01)

        cmds.optionMenu(self.uiButtonTypeContainer,w=80)
        cmds.menuItem(l="selection",p=self.uiButtonTypeContainer)
        cmds.menuItem(l="mel",p=self.uiButtonTypeContainer)
        cmds.menuItem(l="python",p=self.uiButtonTypeContainer)
        cmds.optionMenu(self.uiButtonTypeContainer,e=True, sl=1)

        cmds.button(label="export",p=ah_QS_newselection_ui_row_01,c=partial(self.exportQS))
        cmds.button(label="import",p=ah_QS_newselection_ui_row_01,c=partial(self.importQS))

        #character dropdown
        ah_QS_character_dropdown = cmds.popupMenu(p=self.characterNameField, b=3)

        if len(cmds.getAttr(self.storeNode+"."+self.orderAttr).strip()):
            for ch in cmds.getAttr(self.storeNode+"."+self.orderAttr).split("<||>"):
                text = ch.split(":")[0]
                cmds.menuItem(l=text,c=partial(self.submenuCharacterField,text),stp="python",p= ah_QS_character_dropdown)


        #colors
        cmds.separator(h=2,p=ah_QS_newselection_ui_container)
        self.colorSwitcher(parent=ah_QS_newselection_ui_container)

    def declareUIColors(self):
        self.UIColors={}
        self.UIColors["titleOrange"] = [0.725,0.377,0.126]
        self.UIColors["bgOrange"] = [0.255,0.162,0.080]

        self.UIColors["titleRed"] = [0.569,0.216,0.215]
        self.UIColors["bgRed"] = [0.255,0.115,0.115]

        self.UIColors["titleBlue"] = [0.139,0.356,0.373]
        self.UIColors["bgBlue"] = [0.108,0.190,0.196]

        self.UIColors["titleGreen"]= [0.4,0.623,0.346]
        self.UIColors["bgGreen"] = [0.366116792,0.5949367285,0.1581477225] 

        self.UIColors["textGrey"] = [0.131,0.141,0.176]
        self.UIColors["bgGrey"] = [0.304,0.315,0.353]

        self.UIColors["bgBlack"] = [0.204,0.215,0.253]

    def colorSwitcher(self,parent):
        colors = [0.6455696225,0.1569430828,0.1307482719]     #dark red
        colors +=[1.0,0.3612441421,0.0]                       #light red
        colors +=[0.759493649,0.2759672105,0.0]               #dark orange
        colors +=[1.0,0.5077590942,0.0]                       #light orange
        colors +=[0.708860755,0.4337542951,0.0]               #dark yellow
        colors +=[1.0,0.8708865643,0.0]                       #light yellow
        colors +=[0.366116792,0.5949367285,0.1581477225]      #dark green
        colors +=[0.6324519515,0.8481012583,0.1395609826]     #light green
        colors +=[0.1602307111,0.6329113841,0.453846246]      #dark aqua
        colors +=[0.2161512673,0.8987341523,0.5751565099]     #light aqua
        colors +=[0.0,0.4791859686,0.6075949073]              #dark blue
        colors +=[0.1754526347,0.8116548657,0.9240506291]     #light blue
        colors +=[0.4141757786,0.2489985526,0.531645596]      #dark purple
        colors +=[0.6436779499,0.3028360903,0.8860759735]     #light purple
        colors +=[0.7721518874,0.0,0.6532745361]              #dark pink
        colors +=[0.9367088675,0.2727127075,0.8433365822]     #light pink
        colors +=[0.3797468245,0.3797468245,0.3797468245]     #dark grey
        colors +=[0.6202531457,0.6202531457,0.6202531457]     #light grey
        colors +=[0.9367088675,0.9367088675,0.9367088675]     #white

        #UI
        cmds.rowLayout(h=8,numberOfColumns=19,p=parent,bgc=self.UIColors["bgGrey"])
        cmds.iconTextRadioCollection()
        for n in range(0,len(colors),3):
            color = colors[n:(n+3)]
            cmds.iconTextRadioButton(w=14,h=8, l=" ",onc=partial(self.getColor,color), bgc= color, dgc=self.qsDrag, dpc=self.qsDrop)
        cmds.setParent("..")

    def createSelectScroll(self,parent):

        if len(cmds.getAttr(self.storeNode+"."+self.orderAttr).strip()):
            characters_lists = cmds.getAttr(self.storeNode+"."+self.orderAttr).split("<||>")
        else:
            characters_lists = ""

        os = self.checkOS()

        #UI container (deletes if exists)
        if cmds.columnLayout(self.uiScrollContainer,q=True, ex=True):
            cmds.deleteUI(self.uiScrollContainer)

        cmds.columnLayout(self.uiScrollContainer, bgc= self.UIColors["bgGrey"], p= parent)

        #UI Tabs
        cmds.tabLayout(self.uiScrollTab , p=self.uiScrollContainer,cr=True, mcw=300,w=300, bgc= self.UIColors["bgGrey"],bs="none")

        if len(characters_lists):

            for ch in characters_lists:
                character = ch.split(":")[0]
                selection_lists = ch.split(":")[1].split("||")

                #scroll container
                cmds.rowLayout( character+self.uiMainRow , nc=100, p= self.uiScrollTab, bgc=self.UIColors["bgGrey"])

                #creates slots to put the buttons (delete UI crashs maya when dropCallback)
                for sel in selection_lists:
                    marginRow = cmds.rowLayout(nc=10,p=character+self.uiMainRow, h=52, cal=[1,"center"], bgc=self.UIColors["bgGrey"])

                    slot_name = character + self.uiScrollSlot + str(selection_lists.index(sel))

                    if os == "mac":
                        #if mac add drag and drop callback to rowlayout (bug)
                        cmds.rowLayout( slot_name , p = marginRow , h=40, cal=[1,"center"], dgc = self.qsDrag , dpc = self.qsDrop)
                    else:
                        cmds.rowLayout( slot_name , p=marginRow , h=40, cal=[1,"center"])

                    #creates the buttons
                    bt_parameters = cmds.getAttr(self.storeNode + "." + character+"__"+ sel).split("<||>")
                    bt_color = [float(item) for item in bt_parameters[0].split("/")]
                    bt_type = bt_parameters[1]

                    self.createButton( sel,bt_color, bt_type ,slot_name, character) #label, color, type,...

                #tabs array
                if characters_lists.index(ch) == 0:
                    tabs = [[str(character+self.uiMainRow), str(character)]]
                else:
                    tabs += [[str(character+self.uiMainRow) , str(character)]]

            #put everything in a tab
            cmds.tabLayout(self.uiScrollTab ,e=True, tl = tabs,sc =partial(self.tabsChangeCommand))

        #set tab to current character
        self.selectTab(self.current_character)

        #resizing row
        cmds.evalDeferred(partial(self.resizeTab,"selected"))

    def fixNameSpaceUI(self,*args,**parameters):

        if "missing" in parameters:
            secondScrollLabel = "missing namespaces:"
            title = "fix namespaces"
            missing = 1
        else:
            secondScrollLabel = "button namespaces:"
            title = "fix namespaces for button " + parameters["attr"].split("__")[1] + " in tab " + parameters["attr"].split("__")[0] 
            missing = 0

        fixNSWin = "fixNameSpacesWin"

        if (cmds.window(fixNSWin, exists=True)):
            cmds.deleteUI(fixNSWin)

        self.fixNSmainWindow = cmds.window(fixNSWin,title=title)
        self.Layout = cmds.formLayout()
        self.tit01 = cmds.text(label="scene namespaces:")
        self.tit02 = cmds.text(label=secondScrollLabel)
        self.spacer = cmds.text(label=" ")
        self.scrollListSceneNS = cmds.textScrollList( numberOfRows=8, allowMultiSelection=False,width=300,height=200)
        self.scrollListNS = cmds.textScrollList( numberOfRows=8, allowMultiSelection=False,width=300,height=200)
        self.bt01 = cmds.button(label="fix namespace",c = partial(self.replaceNS,parameters["attr"],missing=missing))
        self.bt02 = cmds.button(label="remove namespace",c = partial(self.replaceNS,parameters["attr"],delete=1,missing=missing))
        self.bt03 = cmds.button(label="cancel",c = partial(self.killNSFixWindow))

        cmds.formLayout(self.Layout, e=1, attachForm=[
                    (self.tit01,"top",5),
                    (self.tit01,"left",5),
                    (self.tit02,"top",5),
                    (self.tit02,"left",310),
                    (self.scrollListSceneNS,"top",20),
                    (self.scrollListSceneNS,"left",5),
                    (self.scrollListNS,"top",20),
                    (self.scrollListNS,"left",310),
                    (self.bt01,"top",230),
                    (self.bt01,"left",310),
                    (self.bt02,"top",230),
                    (self.bt02,"left",400),
                    (self.bt03,"top",230),
                    (self.bt03,"left",515),
                    (self.spacer,"top",250),
                    (self.spacer,"left",612)])
        cmds.showWindow(fixNSWin)

        self.updateSceneNSList()
        if "missing" in parameters:
            self.updateMissingNSList()

        else:
            self.updateNSList(parameters["attr"])

    ####################
    ## drag and drop ###
    ####################

    def qsDrag(self,*a):
        # a[0] dragCtrl,
        # a[1] x,
        # a[2] y,
        # a[3] mods
        pass

    def qsDrop(self,*a):

        # a[0] dragCtrl,
        # a[1] dropCtrl,
        # a[2]
        # a[3] x,
        # a[5] y
        # a[5] mods
        dragCtrl = a[0]
        dropCtrl = a[1]
        x =a[3]
        y =a[4]
        mods = a[5]

        itemDropped = ""
        itemDroppedColor = ""

        print ("dropou!! ",self.current_character)

        os = self.checkOS()

        if os == "mac":
            if cmds.rowLayout(dropCtrl , ex=True):
                childs = cmds.rowLayout(dropCtrl,q=True,ca=True)
                if cmds.button(childs[0], ex=True):
                    itemReceiver = cmds.button( childs[0], q=True , l=True).strip()

        else:
            itemReceiver = cmds.button(dropCtrl , q=True , l=True).strip()

        if cmds.button(dragCtrl, q=True, ex=True):
            itemDropped = cmds.button(dragCtrl, q=True, l=True).strip()
            itemDroppedColor = cmds.button(dragCtrl, q=True, bgc=True)
        elif  cmds.iconTextRadioButton(dragCtrl, q=True, ex=True):
            itemDropped = cmds.iconTextRadioButton(dragCtrl, q=True, l=True).strip()
            itemDroppedColor = cmds.iconTextRadioButton(dragCtrl, q=True, bgc=True)

        if itemDropped == "":

            #color dropped
            newColor = "/".join([str(item) for item in itemDroppedColor])

            #add new color to parameters
            QS_parameters = newColor +"<||>"+ "<||>".join(cmds.getAttr(self.storeNode+"."+self.current_character+"__"+itemReceiver).split("<||>")[1::1])

            #save new attr
            cmds.setAttr( self.storeNode+"."+self.current_character+"__"+itemReceiver, QS_parameters,  type="string")

        else:

            selection_lists = cmds.getAttr(self.storeNode +"."+ self.orderAttr).split("<||>")

            for ch in selection_lists:
                if self.current_character in ch.split(":"):
                    #swap
                    element_list = ch.split(":")[1].split("||")
                    a,b = element_list.index(itemReceiver),element_list.index(itemDropped) # store index
                    #element_list[a],element_list[b] = element_list[b], element_list[a] #swap based on index
                    element_list.remove(itemDropped) # remove dropped item from list
                    element_list.insert(a, itemDropped) # insert dropped item in itemReceiver position

                    ch_list = self.current_character+ ":" + "||".join(element_list)
                else:
                    ch_list = ch

                if selection_lists.index(ch) == 0:
                    new_order = ch_list
                else:
                    new_order += "<||>"+ch_list

            cmds.setAttr( self.storeNode+"."+self.orderAttr , new_order , type="string")

        #refresh scroll
        cmds.evalDeferred(partial(self.uiQuickSelection))


    ##################
    ### get cursor ###
    ##################

    def queryCursorPos(self):
        self.ah_mouseX = QtGui.QCursor.pos().x()
        self.ah_mouseY = QtGui.QCursor.pos().y()
        #print self.ah_mouseX,self.ah_mouseY

    ###################
    ### dummy node ####
    ###################

    # to store all anim help file data

    def dummyNode(self,nome):
        if not cmds.objExists(nome):
            cmds.createNode('script',ss=True, n=nome)

    #######################
    ### quick selection ###
    #######################

    def jumpToSelectionNameField(self,*args):
        self.submenuCharacterField(cmds.textField( self.characterNameField,q=True, text=True))

    def buttonNameFieldReceiveFocus(self,*args):
        self.submenuCharacterField(cmds.textField( self.characterNameField,q=True, text=True))

    def getColor(self,color,*args):
        self.currentColor = color


    def tabsChangeCommand(self,*args):
        self.resizeTab("selected")

    def reposWin(self,*args):

        Height = 0
        Width = 0

        #print self.ah_mouseX,self.ah_mouseY
        if self.contentWidth > 0 :
            Width = self.contentWidth
        else:
            Width = 500

        if self.simpleMode:
            Height= 80
        else:
            Height = cmds.window(self.mainWin,q=True,h=True)

        self.Top = self.ah_mouseY - Height/2 if not self.Top else cmds.window(self.mainWin,q=1,te=1)
        self.Left = self.ah_mouseX - Width/2 if not self.Left else cmds.window(self.mainWin,q=1,le=1)
        

        cmds.window(self.mainWin, e=True, te=self.Top, le=self.Left,vis=1,w=Width,h=Height)

    def resizeTab(self,tab,*args):

        if cmds.tabLayout(self.uiScrollTab,q=True,ca=True):

            if tab == "selected":
                #get selected tab
                current_row_layout = cmds.tabLayout(self.uiScrollTab,q=True,st=True)
                current_scroll_childs = cmds.rowLayout( current_row_layout , q=True, ca=True)
            else:
                #get tab index received as parameter
                current_row_layout = cmds.tabLayout(self.uiScrollTab,q=True,ca=True)[tab]
                current_scroll_childs = cmds.rowLayout( current_row_layout , q=True, ca=True)

            self.current_character = current_row_layout.replace( self.uiMainRow ,"")
            cmds.optionVar(sv=("ahCurrentCharacter",self.current_character))

            row_width = 0

            for e in current_scroll_childs:
                row_width += cmds.rowLayout(e, q=True,w=True)+3

            if row_width < 500:
                row_width = 500

            cmds.tabLayout(self.uiScrollTab,e=True,w=row_width)

            self.contentWidth = row_width

        #repos win
        cmds.evalDeferred(partial(self.reposWin))


    def selectTab(self,character):

        try:
            cmds.tabLayout(self.uiScrollTab, e=True, st=character+self.uiMainRow)
        except:
            print ("new character selection ",character)

        self.current_character = character
        cmds.optionVar(sv=("ahCurrentCharacter",self.current_character))


    def setCurrCharacterFirstTime(self):

        if len (cmds.getAttr(self.storeNode +"."+ self.orderAttr).strip()):
            self.current_character = cmds.getAttr(self.storeNode +"."+ self.orderAttr).split("<||>")[0].split(":")[0]
            cmds.optionVar(sv=("ahCurrentCharacter",self.current_character))
        else:
            self.current_character = ""
            cmds.optionVar(sv=("ahCurrentCharacter",self.current_character))

        print ("first time QS!!!")


    def setCurrentCharacter(self,character):

        if not len(character):
            current_character = cmds.tabLayout(self.uiScrollTab, q=1, st=1).replace(self.uiMainRow,"")
            cmds.optionVar(sv=("ahCurrentCharacter",self.current_character))
        else:
            current_character = character
            cmds.optionVar(sv=("ahCurrentCharacter",self.current_character))

        #print current_character

    def submenuCharacterField(self,text,*args):
        cmds.textField( self.characterNameField ,e=True, tx=text)
        cmds.setFocus(self.buttonNameField)
        self.selectTab( cmds.textField( self.characterNameField ,q=True,text=True) )
        cmds.evalDeferred( partial(self.resizeTab,"selected") )


    def createButton(self, label, color, bt_type, parent, character):

        ch_prefix = character + "__"
        menuPrefix = "submenu_"
        h =40
        w = 200
        al = "center"
        c = ""
        margin = 20
        label_offset = 20

        cmds.button( self.btPrefix + label ,al=al, p = parent , h=h, bgc= color, dgc = self.qsDrag , dpc = self.qsDrop)
        #cmds.evalDeferred("maya.cmds.rowLayout(cmds.iconTextButton('"+ btPrefix + label +"', q=True, p=True) , e =True, bgc = "+str(color)+", w= (maya.cmds.iconTextButton('"+ btPrefix + label +"',q=True, w=True)+15),cal=(1,'center') )")

        #bt submenu
        cmds.popupMenu( menuPrefix + label , p = self.btPrefix + label , b=3 )

        if bt_type == "mel" or bt_type == "python":
            cmds.menuItem( l="execute",         c = partial(self.runScript , label , bt_type , character))
            cmds.menuItem( d=1)
            cmds.menuItem( l="edit",            c = partial(self.editScript , label , bt_type , character) )
            cmds.menuItem( d=1)
            cmds.menuItem( l="rename",          c = partial(self.renameButton , label , character))
            cmds.menuItem( l="delete",          c = partial(self.deleteButton , character+"__"+label , character))
            cmds.setParent('..')
            cmds.button( self.btPrefix + label, e=1,c = partial(self.runScript , label , bt_type , character) ,l="[ # ] "+label+"   ")

        else:

            cmds.menuItem( l="select",              c = partial(self.makeSelection , character+"__"+label ))
            cmds.menuItem( l="select [ + ]",        c = partial(self.makeSelectionAdd ,  character+"__"+label ))
            cmds.menuItem( l="select [ - ]",        c = partial(self.makeSelectionRm , character+"__"+label ))
            cmds.menuItem( d=1)
            cmds.menuItem( l="add itens",           c = partial(self.addToSelecionList , label , character ))
            cmds.menuItem( l="remove itens",        c = partial(self.removeFromSelectionList , label , character ))
            cmds.menuItem( d=1)
            cmds.menuItem( l="change NAMESPACES",   c = partial(self.fixNameSpaceUI , attr = character+"__"+label ))
            #cmds.menuItem( l="button to other TAB", c = partial(self.listSceneNameSpaces))
            cmds.menuItem( d=1)
            cmds.menuItem( l="rename",              c = partial(self.renameButton , label , character ))
            cmds.menuItem( l="delete",              c = partial(self.deleteButton , character+"__"+label , character ))
            cmds.setParent('..')
            cmds.button(self.btPrefix + label , e=True, c = partial(self.makeSelection ,  character+"__"+label ) ,l="  "+label+"   ")



    def new(self,*args):

        character = cmds.textField( self.characterNameField, q=True , text=True)
        selection_name = cmds.textField( self.buttonNameField , q=True , text=True)

        #erros
        if not len(character):
            cmds.error( 'type the character name!')
        elif not len(selection_name):
            cmds.error( 'type the button name!')

        #selection or script

        if cmds.optionMenu(self.uiButtonTypeContainer, q=1, v=1) == "selection":
            if len(cmds.ls(sl=1)):
                self.newSelection()
            else:
                cmds.error( 'select object(s) to create a selection button!')
        else:
            self.newScript(selection_name)

    def newSelection(self):

        elements = "//".join(cmds.ls(sl=True))
        self.saveNew(elements)


    def newScript(self,name):

        s_type = cmds.optionMenu( self.uiButtonTypeContainer , q=True, v=True)
        title = "enter "+s_type+" script buttom: "+name
        save = CommandWindow( title, self ,"save","","",s_type,"")

    def saveNew(self,elements):

        s_type = cmds.optionMenu( self.uiButtonTypeContainer , q=True, v=True)
        character = cmds.textField( self.characterNameField, q=True , text=True)
        selection_name = cmds.textField( self.buttonNameField , q=True , text=True)
        attr = character+"__"+selection_name

        #add parameters creation to selection list # color, type, style, img
        QS_parameters =  "/".join([str(item) for item in self.currentColor]) +"<||>"+ s_type +"<||>"+ elements  # color, type, list

        #create attribute with selection string (and index at first)
        self.addAttr( attr , QS_parameters, self.storeNode , character)

        #clear fields and set focus
        cmds.textField( self.characterNameField, e=True , text="")
        cmds.textField( self.buttonNameField , e=True , text="")

        cmds.setFocus(self.uiScrollTab)
        self.setCurrentCharacter(character)

        #refresh list
        cmds.evalDeferred(partial(self.uiQuickSelection))

    def runScript(self,label,bt_type,character,*args):

        script = cmds.getAttr(self.storeNode+"."+character+"__"+label).split("<||>")[-1]

        if bt_type =="mel":
            cmds.evalDeferred("import maya.mel as mel; mel.eval('"+script.replace("\n","\\n").replace("\r","\\r")+"')")
        else:
            cmds.evalDeferred(script)

    def editScript(self,label,bt_type,character,*args):

        script = cmds.getAttr(self.storeNode+"."+character+"__"+label).split("<||>")[-1]
        title = "edit "+bt_type+" script: " + label
        edit = CommandWindow( title , self , "edit",label,character,bt_type,script)

    def saveScript (self,script,bt_type,label,character):

        attr_name = self.storeNode+"."+character+"__"+label
        attr_content = cmds.getAttr( attr_name ).split("<||>")
        current_elements = script

        new_attr_content = "<||>".join(attr_content[0:-2]) +"<||>"+ bt_type +"<||>"+current_elements

        cmds.setAttr( attr_name , new_attr_content, type="string")

        # refresh list
        cmds.evalDeferred(partial(self.uiQuickSelection))


    def renameButton(self,label,character,*args):

        dialogW = cmds.promptDialog( t="rename quick selection", m="Please, type a new unique name:", button = ["OK","Cancel"], defaultButton="OK", cancelButton="Cancel", dismissString="")
        newName = cmds.promptDialog( q=True,tx=True)

        if not newName == "":

            #checking if name exists
            if (character+"__"+newName) in cmds.listAttr(self.storeNode , ud=True):
                cmds.error( 'Custom selection name already exists! :S')
            else:
                #rename attribute
                print (self.storeNode + "." + character+"__"+label)
                cmds.renameAttr( self.storeNode + "." + character+"__"+label , character+"__"+newName)

                #rename list attribute
                selection_lists = cmds.getAttr(self.storeNode +"."+ self.orderAttr).split("<||>")

                for ch in selection_lists:
                    if character in ch.split(":"):
                        element_list = ch.split(":")[1].split("||")

                        for element in element_list:
                            n = element_list.index(element)
                            if element == label:
                                element_list[n] = newName

                        ch_list = character+ ":" + "||".join(element_list)
                    else:
                        ch_list = ch

                    if selection_lists.index(ch) == 0:
                        new_order = ch_list
                    else:
                        new_order += "<||>"+ch_list

            cmds.setAttr( self.storeNode+"."+self.orderAttr , new_order , type="string")

            # refresh list
            cmds.evalDeferred(partial(self.uiQuickSelection))

    def addToSelecionList(self,label,character,*args):

        selection = cmds.ls(sl=True)

        attr_name = self.storeNode+"."+character+"__"+label
        attr_content = cmds.getAttr( attr_name ).split("<||>")
        current_elements = attr_content[-1] + "//" + ("//".join(selection))

        new_attr_content = "<||>".join(attr_content[0:-1]) +"<||>"+ current_elements

        cmds.setAttr( attr_name , new_attr_content, type="string")


    def removeFromSelectionList(self,label,character,*args):

        selection = cmds.ls(sl=True)

        attr_name = self.storeNode+"."+character+"__"+label
        attr_content = cmds.getAttr( attr_name ).split("<||>")
        current_elements = attr_content[-1].split("//")

        for s in selection:
            if s in current_elements:
                current_elements.remove(s)

        new_attr_content = "<||>".join(attr_content[0:-1]) +"<||>"+ "//".join(current_elements)

        cmds.setAttr( attr_name , new_attr_content, type="string")


    def deleteButton( self, attr,character,*args):

        #delete attr
        self.deleteAttr ( attr , character)
        #refresh
        cmds.evalDeferred(partial(self.uiQuickSelection))


    def makeSelection(self, attr, *args):
        currentPanel= cmds.getPanel(wf=True)

        mods = cmds.getModifiers()
        print ("mods --- ", mods)
        #mods:
        #1 --> shift
        #4 --> ctrl
        #5 --> ctrl+shift
        #8 --> alt

        if mods == 1:
            self.makeSelectionAdd(attr)
        elif mods == 4:
            self.makeSelectionRm(attr)
        else:
            cmds.select(cl=True)
            self.makeSelectionAdd(attr)

        cmds.setFocus(currentPanel)


    def makeSelectionAdd(self,attr,*args):

        currentPanel= cmds.getPanel(wf=True)

        cmds.select( self.cleanupList( cmds.getAttr( self.storeNode+"."+attr).split("<||>")[2].split("//") ) , add=True)
        cmds.setFocus(currentPanel)

    def cleanupList(self,elements):
        # check if any obj in selection list dont exists anymore and remove it from list
        for e in elements:
            if not cmds.objExists(e):
                elements.remove(e)

        return elements


    def makeSelectionRm(self,attr,*args):

        currentPanel= cmds.getPanel(wf=True)

        cmds.select( self.cleanupList(cmds.getAttr( self.storeNode+"."+attr).split("<||>")[2].split("//")) , d=True)
        cmds.setFocus(currentPanel)

    def addAttr(self,attr, value, node, character):

        attr = attr.replace(" ","_")# to cleanup in case of input of blank space

        #checking if attr exists
        if attr in cmds.listAttr(self.storeNode , ud=True):
            cmds.error(">>> Custom selection name already exists! :S")

        #checking empty value
        elif value=="" :
            cmds.error(">>> Custom selection is empty! Select at least one element.")
        else:
            cmds.addAttr(node,ln=attr,h=False,dt="string")
            cmds.setAttr(node+"."+attr, value ,type="string")

            #add to atribute order (rebuild the string)
            selection_lists = cmds.getAttr(self.storeNode +"."+ self.orderAttr).split("<||>")
            character_exists_in_list = 0

            if len(cmds.getAttr(self.storeNode +"."+ self.orderAttr)):

                for sl in selection_lists:
                    if character in sl.split(":"):
                        ch_list = character+ ":" + sl.split(":")[1] + "||" + attr.replace((character+"__"),"")
                        character_exists_in_list = 1
                    else:
                        ch_list = sl

                    if selection_lists.index(sl) == 0:
                        new_order = ch_list
                    else:
                        new_order += "<||>"+ch_list

                if not character_exists_in_list:
                    new_order = cmds.getAttr(self.storeNode +"."+ self.orderAttr)
                    new_order += "<||>"+character +":"+ attr.replace((character+"__"),"")

            else:
                new_order = character +":"+ attr.replace((character+"__"),"")

            cmds.setAttr( self.storeNode+"."+self.orderAttr , new_order , type="string")

    def deleteAttr( self ,attr, character):

        #delete attribute
        cmds.deleteAttr(self.storeNode , at=attr)

        new_order = ""

        #delete from atribute order
        selection_lists = cmds.getAttr(self.storeNode +"."+ self.orderAttr).split("<||>")
        for ch in selection_lists:
            if character in ch.split(":"):
                selection_list = ch.split(":")[1].split("||")
                selection_list.remove(attr.replace(character+"__",""))

                if not len(selection_list):
                    ch_list = ""
                else:
                    ch_list = character+ ":" + "||".join(selection_list)
            else:
                ch_list = ch

            if new_order == "" and len(ch_list):
                new_order = ch_list
            elif len(ch_list):
                new_order += "<||>"+ch_list

            #print "NEW ORDER >>> ", new_order

        cmds.setAttr( self.storeNode+"."+self.orderAttr , new_order , type="string")

    #######################
    ## fix namespaces    ##
    #######################

    def listNameSpaces(self,*args,**parameters):


        selections = cmds.listAttr(self.storeNode,ud=1)
        nameSpaces = []
        elements = []

        if "attr" in parameters:
            attr = parameters["attr"]
            if attr in selections:
                [elements.append(e) for e in sorted(set(cmds.getAttr( self.storeNode+"."+attr).split("<||>")[2].split("//"))) if not cmds.getAttr( self.storeNode+"."+attr).split("<||>")[1]=="python" or cmds.getAttr( self.storeNode+"."+attr).split("<||>")[1]=="mel"]
        else:
            for s in selections:
                if not s == "list_order":
                    [elements.append(e) for e in sorted(set(cmds.getAttr( self.storeNode+"."+s).split("<||>")[2].split("//"))) if not cmds.getAttr( self.storeNode+"."+s).split("<||>")[1]=="python" or cmds.getAttr( self.storeNode+"."+s).split("<||>")[1]=="mel"]

        nameSpaces = [n for n in sorted(set([":".join(e.split(":")[0:-1]) for e in sorted(set(elements))]))]

        for n in nameSpaces:
            if n == "":
                nameSpaces[nameSpaces.index(n)] = "[None]"

        return nameSpaces

    def replaceNS(self,attr,*args,**parameters):

        attrs = []
        newNS=None
        oldNS=None

        if cmds.textScrollList(self.scrollListSceneNS,q=1,si=1):
            newNS = cmds.textScrollList(self.scrollListSceneNS,q=1,si=1)[0] 
        if cmds.textScrollList(self.scrollListNS,q=1,si=1):
            oldNS = cmds.textScrollList(self.scrollListNS,q=1,si=1)[0]

        if attr == ">>all<<":
            attrs = [a for a in cmds.listAttr(self.storeNode,ud=1) if not a =="list_order"]
        else:
            attrs.append(attr)

        for a in attrs:

            attr_name = self.storeNode+"."+a
            attr_content = cmds.getAttr( attr_name ).split("<||>")
            current_elements = attr_content[-1].split("//") 
            newElements = []

            if oldNS:
                for e in current_elements:
                    if "delete" in parameters:
                        if parameters["delete"]:
                            if oldNS == ":".join(e.split(":")[0:-1]):
                                newElements.append(e.split(":")[-1])
                            else:
                                newElements.append(e)
                    else:
                        if oldNS == ":".join(e.split(":")[0:-1]) or oldNS == "[None]":
                            newElements.append(newNS + ":" + e.split(":")[-1])
                        else:
                            newElements.append(e)

                new_attr_content = "<||>".join(attr_content[0:-1]) +"<||>"+ "//".join(newElements)

                cmds.setAttr( attr_name , new_attr_content, type="string")

                self.updateSceneNSList()

                if "missing" in parameters:
                    if parameters["missing"]:
                        self.updateMissingNSList()
                    else:
                        self.updateNSList(a)
                else:
                    self.updateNSList(a)
            


    def listSceneNameSpaces(self,*args):
        #namespaces = cmds.namespaceInfo(listOnlyNamespaces=True, recurse=True)
        namespaces = cmds.namespaceInfo(lon=1) #[r.replace("RN","") for r in cmds.ls(type="reference")]
        return namespaces

    def checkMissingNS(self,*args):
        sceneNS = self.listSceneNameSpaces()
        selectionsNS = self.listNameSpaces()
        missingNS = []

        for ns in selectionsNS:
            if not ns in sceneNS and not ns == "[None]":
                missingNS.append(ns)

        return missingNS

    def updateSceneNSList(self):
        nss = self.listSceneNameSpaces()
        cmds.textScrollList(self.scrollListSceneNS,e=1,ra=1) #clear
        if nss:
            for n in nss:
                cmds.textScrollList(self.scrollListSceneNS,e=1,append=n)

    def updateMissingNSList(self):
        nss = self.checkMissingNS()
        cmds.textScrollList(self.scrollListNS,e=1,ra=1) #clear
        if nss:
            for n in nss:
                cmds.textScrollList(self.scrollListNS,e=1,append=n)
        else:
            print ("teria que deletar porra!")
            cmds.deleteUI(self.fixNSmainWindow,window=True)
            

    def updateNSList(self,attr,*args):
        nss = self.listNameSpaces(attr=attr)
        cmds.textScrollList(self.scrollListNS,e=1,ra=1) #clear
        if nss:
            for n in nss:
                cmds.textScrollList(self.scrollListNS,e=1,append=n)

    def killNSFixWindow(self,*args):
        cmds.deleteUI(self.fixNSmainWindow,window=True)

    #######################
    ## export and import ##
    #######################

    def exportQS (self,*args):
        #export
        node = self.storeNode
        multipleFilters = "*.json"
        exportName  = cmds.fileDialog2(fileFilter=multipleFilters, dialogStyle=1,okc="export quick selection")

        if not exportName == None:
            attrs = cmds.listAttr(node,ud=1)
            data = {}

            for a in attrs:
                data[str(a)] = str(cmds.getAttr(node+"."+a))

            self.saveDataTxt (data,exportName[0])
            print ("exported!")

    def importQS (self, *args):

        currentQS = self.readPreviousQS()

        #import
        node = self.storeNode
        multipleFilters = "*.json"
        importName  = cmds.fileDialog2(fileFilter=multipleFilters,fileMode=1, dialogStyle=1,okc="import quick selection")

        if not importName == None:
            data = self.readDataTxt(importName[0])
            importStuff = True
            
            oldKeysToKeep = self.compareQS(currentQS,data)#compare differences between current QS and imported QS

            if oldKeysToKeep:
                dialogW = cmds.confirmDialog( t="Merge or replace", m="Merge or replace current Quick Selection?", button = ["Replace","Merge","Cancel"], defaultButton="Replace", cancelButton="Cancel", dismissString="Cancel")
 
                if dialogW=="Merge":
                    #merge data
                    newData = self.mergeQS(currentQS,data,oldKeysToKeep)
                    data = newData

                if dialogW=="Cancel":

                    importStuff = False

            if importStuff:
                #clear
                attrs = cmds.listAttr(node,ud=1)
                for a in attrs:
                    cmds.deleteAttr(node+"."+a)

                #rewrite
                for a in data:
                    cmds.addAttr(node,ln=a,dt="string")
                    cmds.setAttr(node+"."+a,data[a],type="string")

                self.uiQuickSelection()

                if self.checkMissingNS():
                    self.fixNameSpaceUI(missing=1,attr=">>all<<")

                print ("imported")

    def readPreviousQS(self,*args):
        #export
        node = self.storeNode

        if cmds.objExists(node):

            attrs = cmds.listAttr(node,ud=1)
            data = {}

            for a in attrs:
                data[str(a)] = str(cmds.getAttr(node+"."+a))

            return data

    def compareQS(self,currentQS,importedQS):

        oldKeys = currentQS.keys()
        importedKeys = importedQS.keys()
        oldKeysToKeep = []

        for k in oldKeys:
            if not k in importedKeys and not k =="list_order":
                oldKeysToKeep.append(k)

        return oldKeysToKeep

    def mergeQS(self,currentQS,importedQS,oldKeysToKeep):

        currentOrder = currentQS["list_order"]
        importedOrder = importedQS["list_order"]
        currentOrderFiltered = []
        newOrderAttr = ""

        #dicts
        currentOrderDict = {}
        importedOrderDict = {}
        newOrderDict = {}
        oldKeysToKeepDict = {}

        newQS = currentQS #dict

        # build dict with dictionary "<tab name>" : ["element01","element02",etc]
        for k in oldKeysToKeep:
            tabName = k.split("__")[0]
            attrName = "__".join(k.split("__")[1:])

            if tabName in oldKeysToKeepDict:
                oldKeysToKeepDict[tabName].append(attrName)
            else:
                oldKeysToKeepDict[tabName]=[attrName]

        # current order dictionary
        for i in currentOrder.split("<||>"):
            tabName = i.split(":")[0]
            elements = i.split(":")[1].split("||")

            for e in elements:
                if tabName in currentOrderDict:
                    currentOrderDict[tabName].append(e)
                else:
                    currentOrderDict[tabName]=[e]

        # imported order dictionary
        for i in importedOrder.split("<||>"):
            tabName = i.split(":")[0]
            elements = i.split(":")[1].split("||")

            for e in elements:
                if tabName in importedOrderDict:
                    importedOrderDict[tabName].append(e)
                else:
                    importedOrderDict[tabName]=[e]

        #merged order dictionary
        newOrderDict = currentOrderDict

        for k in importedOrderDict:
            if k in newOrderDict:
                newOrderDict[k] = [e for e in set(newOrderDict[k] + importedOrderDict[k])]
            else:
                newOrderDict[k] = importedOrderDict[k]

        #merged order attr
        newOrderArray =[]
        for tab in newOrderDict:
            newOrderArray.append(tab+":"+"||".join(newOrderDict[tab]))

        newOrderAttr = "<||>".join(newOrderArray)

        #output dictionary

        for k in importedQS:
            newQS[k] = importedQS[k]

        newQS["list_order"]=newOrderAttr

        return newQS


    def saveDataTxt (self,data,filepath):
        fileWrite = open(filepath, 'w')
        fileWrite.write(str(data))
        fileWrite.close()

    def readDataTxt (self,filepath):

        fileData = open(filepath, "r").read()
        exec("fileData = "+fileData)

        return fileData



#######################
## Command Window    ##
#######################


class CommandWindow:

    def __init__(self,title,caller,action,label,character,lang,text):
        
        self.caller=caller

        self.command_win = "anim_helpers_command_win"
        self.command_field_container_mel = "anim_helpers_command_field_container_mel"
        self.command_field_mel = "anim_helpers_command_field_mel"
        self.command_field_container_python = "anim_helpers_command_field_container_python"
        self.command_field_python = "anim_helpers_command_field_python"
        self.command_fields_parent = "anim_helpers_command_fields_parent"
        self.command_lang = "anim_helpers_command_lang"
        self.current_lang =lang
        self.label = label
        self.character = character
        self.action = action
        self.title = title
        self.text = text

        self.win()

    def clickOk(self,*args):

        if self.action =="save":
            if self.current_lang == "mel":
                cmds.optionMenu(self.caller.uiButtonTypeContainer,e=1,sl=2) #mel script
            else:
                cmds.optionMenu(self.caller.uiButtonTypeContainer,e=1,sl=3) #python script

            self.caller.saveNew(self.getText())

        elif self.action =="edit":
            self.caller.saveScript(self.getText(),self.getType(),self.label,self.character)  

    def win(self):

        if cmds.window(self.command_win, q=1, ex=1):
            cmds.deleteUI(self.command_win)

        cancel_cmd = "cmds.deleteUI('"+self.command_win+"')"

        cmds.window(self.command_win,rtf=1,t=self.title)
        cmds.columnLayout(w=600,h=300,cal="right")

        cmds.columnLayout(self.command_fields_parent)

        cmds.rowLayout(self.command_field_container_mel,vis=1)
        cmds.cmdScrollFieldExecuter(self.command_field_mel,width=600, height=300,t=self.text, sourceType="mel")
        cmds.setParent("..")

        cmds.rowLayout(self.command_field_container_python,vis=0)
        cmds.cmdScrollFieldExecuter(self.command_field_python,width=600, height=300,t=self.text, sourceType="python")
        cmds.setParent("..")

        cmds.setParent("..")

        cmds.separator(h=5)

        cmds.rowLayout(nc=4)
        cmds.button(l="ok",w=295, c=partial(self.clickOk))
        cmds.text(l="  ")
        cmds.button(l="cancel",w=295,c=cancel_cmd)

        cmds.popupMenu(self.command_lang, p=self.command_fields_parent)
        cmds.menuItem(l="mel",p=self.command_lang,c= partial(self.editCommandField,"mel") , stp="python")
        cmds.menuItem(l="python",p=self.command_lang,c= partial(self.editCommandField,"python") , stp="python")
     

        cmds.setParent("..")
        cmds.showWindow()

        self.editCommandField(self.current_lang)

        cmds.window(self.command_win,e=1,s=0,w=604,h=340)

    def editCommandField (self,lang,*args):

        self.current_lang=lang

        if lang == "mel":
            visPython = 0
            visMel = 1
            text = cmds.cmdScrollFieldExecuter(self.command_field_python,q=1,t=1)
            
        else:
            visPython = 1
            visMel = 0
            text = cmds.cmdScrollFieldExecuter(self.command_field_mel,q=1,t=1)
            
        cmds.rowLayout(self.command_field_container_python,e=1,vis=visPython)
        cmds.rowLayout(self.command_field_container_mel,e=1,vis=visMel)

        cmds.cmdScrollFieldExecuter(self.command_field_python,e=1,t=self.text)
        cmds.cmdScrollFieldExecuter(self.command_field_mel,e=1,t=self.text)

        self.changeTitle()


    def getText(self):

        if cmds.rowLayout(self.command_field_container_mel,q=1,vis=1) == 1:
            text = cmds.cmdScrollFieldExecuter(self.command_field_mel,q=1,t=1)
        else:
            text = cmds.cmdScrollFieldExecuter(self.command_field_python,q=1,t=1)
      
        print (text)
        cmds.evalDeferred('cmds.deleteUI("'+self.command_win+'")')

        return text

    def getType(self):

        if cmds.rowLayout(self.command_field_container_mel,q=1,vis=1) == 1:
            script_type = "mel"
        else:
            script_type = "python"

        return script_type

    def changeTitle(self):
        
        if self.current_lang=="python":
            new_title = cmds.window(self.command_win,q=1,title=1).replace(" mel "," python ")
        elif self.current_lang=="mel":
            new_title = cmds.window(self.command_win,q=1,title=1).replace(" python "," mel ")

        cmds.window(self.command_win,e=1,t=new_title)


print ("QuickSelection module reloaded.")

#USAGE:
qs = QuickSelection()
qs.toggleWin(0) # <---- 1 to simple mode, 0 to full mode
