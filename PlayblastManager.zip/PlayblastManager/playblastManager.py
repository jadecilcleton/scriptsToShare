import maya.cmds as cmds
import maya.mel as mel
import pymel.core as pm    
import os
from stat import S_ISREG, ST_CTIME, ST_MODE
import sys, time
from functools import partial
import datetime
import subprocess

#to be able to import scirpts in same folder of this one
script_path = os.path.dirname(os.path.abspath( __file__ ))
if not script_path in sys.path: sys.path.append(script_path)

import ffmpeg

#to save when playblast
import saveFile
reload (saveFile)
SF = saveFile.Save()

       

class PlayblastManager:
    def __init__(self):
        self.load()


    def load(self):
        
        self.tempDir = cmds.internalVar(userTmpDir=1)
        self.maximunPlayblastFiles = 30

        self.storeNode="playblastManager_DATA"
        self.playblastManagerNode(self.storeNode)
        self.namesAndFolders()
       
        self.UI()

    def checkOS(self):
        sys=""
        checkOs = cmds.about(os=True)

        if checkOs == "mac":

            # IF MAC - escreve o comando para abrir o finder
            sys = "mac"

        elif checkOs == "nt" or checkOs == "win64":

            sys = "win"

        else:

            sys = "linux"

        return sys


    def namesAndFolders(self):
        #vars   
        self.plablastSufix = "_wip_"
        self.fullpath = cmds.file(q=1,sn=1)
        self.filename = os.path.basename(self.fullpath)
        self.filepath = self.fullpath.replace(self.filename,"")
        self.raw_name, self.extension = os.path.splitext(self.filename)
        self.handBrakePath = os.path.dirname(os.path.abspath( __file__ ))+"/HandBrakeCLI/HandBrakeCLI.exe"  

        self.storeFolder = cmds.getAttr(self.storeNode+".folder") if cmds.getAttr(self.storeNode+".folder") != "" else self.tempDir
        
        self.playblastPath = self.storeFolder
        self.apresentPath = self.storeFolder+"/_present"

        if not os.path.exists(self.apresentPath):
            #os.makedirs(self.playblastPath)
            os.makedirs(self.apresentPath)

    def listFilesSortedByDate(self,givenPath):

        # path to the directory (relative or absolute)
        #dirpath = sys.argv[1] if len(sys.argv) == 2 else r'.'
        dirpath = givenPath

        dirStuff = os.listdir(dirpath)

        if dirStuff:
            # get all entries in the directory w/ stats
            entries = (os.path.join(dirpath, fn) for fn in dirStuff)
            entries = ((os.stat(path), path) for path in entries)

            # leave only regular files, insert creation date
            entries = ((stat[ST_CTIME], path)
                       for stat, path in entries if S_ISREG(stat[ST_MODE]))
            #NOTE: on Windows `ST_CTIME` is a creation date 
            #  but on Unix it could be something else
            #NOTE: use `ST_MTIME` to sort by a modification date
            sortedFiles = []
            for cdate, path in sorted(entries):
                if ".mov" in path or ".mp4" in path:
                    sortedFiles.append(os.path.basename(path))
                    #print time.ctime(cdate), os.path.basename(path)

            return sortedFiles


    def getLastIndex(self,**param):

        updateField = param["updateField"] if "updateField" in param else 0

        sortedPlayblastFiles = self.listPlayblasts()
        playblastsFromThisFile = []
        if sortedPlayblastFiles:
            for f in sortedPlayblastFiles:
                #listing playblast from current file
                if self.raw_name == f.split(self.plablastSufix)[0]:
                    playblastsFromThisFile.append(f)

        #if there is already playblast from current file  
        if len(playblastsFromThisFile):
            lastIndex = int(os.path.splitext(playblastsFromThisFile[-1])[0].split(self.plablastSufix)[-1])
            index = '%04d' % (lastIndex)
        else:
            index = "0001"

        storedIndex = cmds.getAttr(self.storeNode+".version")

        if storedIndex > int(index):
            index = storedIndex

        cmds.setAttr(self.storeNode+".version",int(index))

        if updateField:
            cmds.intField(self.version_input,e=1,minValue=cmds.intField(self.version_input,q=1,v=1))

        return int(index)

    def getFolder(self,*args):
        multipleFilters = "*.mov"
        if self.playblastPath != "":
            result = cmds.fileDialog2(fileFilter=multipleFilters, dialogStyle=1,okc="choose this folder",dir=self.playblastPath,fm=2)
        else:
            result = cmds.fileDialog2(fileFilter=multipleFilters, dialogStyle=1,okc="choose this folder",fm=2)

        if result != None:

            cmds.setAttr(self.storeNode+".folder",result[0],type="string")
            cmds.textField(self.folder_input,edit=1,text=result[0])

            return result[0]
                      
    def listPlayblasts(self,**param):

        self.namesAndFolders()

        folder = param["folder"] if "folder" in param else self.playblastPath
        
        #list plablastFiles    
        dir_stuff=os.listdir(folder)
        
        playblastFiles = [ f for f in dir_stuff if os.path.isfile(os.path.join(folder,f)) and self.plablastSufix in f ]
        sortedPlayblastFiles = self.listFilesSortedByDate(folder)

        return sortedPlayblastFiles

    def keepMaximunPlayblasts(self):

        sortedPlayblastFiles = self.listPlayblasts()

        #keep maximun number of autosave files
        if len(sortedPlayblastFiles) >= self.maximunPlayblastFiles:
            cmds.sysFile( os.path.join(self.playblastPath,sortedPlayblastFiles[0]) , delete=True )

    def attrLists(self,*args,**param):
        #check boxes

        #                [UI element                        ,attribute       ,default value]

        self.checkAttrs=[["self.ckb_vp20              "     ,"vp20"          , 1 ],
                         ["self.ckb_hud               "     ,"hud"           , 0 ],
                         ["self.ckb_ao                "     ,"ao"            , 1 ], 
                         ["self.ckb_lights            "     ,"lights"        , 0 ],  
                         ["self.ckb_antialiasing      "     ,"aa"            , 0 ],      
                         ["self.ckb_generatecompressed"     ,"compressed"    , 0 ],                  
                         ["self.ckb_panzom            "     ,"panzoom"       , 0 ],   
                         ["self.ckb_locators          "     ,"locators"      , 0 ],        
                         ["self.ckb_wireframeOnShaded "     ,"wireShaded"    , 0 ],                  
                         ["self.ckb_textures          "     ,"textures"      , 0 ],        
                         ["self.ckb_shadows           "     ,"shadows"       , 0 ],   
                         ["self.ckb_fog               "     ,"fog"           , 0 ],    
                         ["self.ckb_flatShaded        "     ,"flatShaded"    , 0 ],
                         ["self.ckb_showSelected"           ,"showSelected"  , 0 ]]          
        
        
        #input text
        self.textAttrs= [["self.basename_input        "     ,"basename"      , ""],
                         ["self.folder_input          "     ,"folder"        , self.tempDir]]


        #input text outside of the UI
        self.textNoUIAttrs = ["lastPlayblast" ]

        #input int
        self.intAttrs=  [["self.version_input         "     ,"version"        , 0 ],
                         ["self.w_input               "     ,"width"          , 0 ],   
                         ["self.h_input               "     ,"height"         , 0 ], 
                         ["self.start_input           "     ,"start"          , 0 ],
                         ["self.end_input             "     ,"end"            , 0 ],
                         ["self.compress_input"             ,"compression"    , 75 ]]

        #option menus
        self.optAttrs=  [["self.camera_dropdown       "     ,"camera"         , "perspShape"]]

    
    def saveDATA(self,*args,**param):

        self.attrLists()

        for attr in self.checkAttrs:
            command = 'cmds.setAttr("{0}.{1}",cmds.checkBox({2},q=1,v=1))'.format(self.storeNode,attr[1],attr[0])
            exec(command)

        for attr in self.intAttrs:
            command = 'cmds.setAttr("{0}.{1}",cmds.intField({2},q=1,v=1))'.format(self.storeNode,attr[1],attr[0])
            exec(command)

        for attr in self.textAttrs:
            command = 'cmds.setAttr("{0}.{1}",cmds.textField({2},q=1,text=1),type="string")'.format(self.storeNode,attr[1],attr[0])
            exec(command)

        for attr in self.optAttrs:
            command = 'cmds.setAttr("{0}.{1}",cmds.optionMenu({2},q=1,v=1),type="string")'.format(self.storeNode,attr[1],attr[0])
            exec(command)


    def readDATA(self,*args,**param):

        self.attrLists()

        for attr in self.checkAttrs:
            command = 'cmds.checkBox({2},e=1,v=cmds.getAttr("{0}.{1}"))'.format(self.storeNode,attr[1],attr[0])
            exec(command)

        for attr in self.intAttrs:
            command = 'cmds.intField({2},e=1,v=cmds.getAttr("{0}.{1}"))'.format(self.storeNode,attr[1],attr[0])
            exec(command)

        for attr in self.textAttrs:
            command = 'cmds.textField({2},e=1,text=cmds.getAttr("{0}.{1}"))'.format(self.storeNode,attr[1],attr[0])
            exec(command)

        for attr in self.optAttrs:
            #get list of itens
            cmd = 'menusItens = cmds.optionMenu({0},q=1,ill=1)'.format(attr[0])
            exec(cmd)
            menus = []
            for m in menusItens:
                menus.append( cmds.menuItem(m,q=1,l=1) )
            #check if stored value item exists in the list menus and set it if TRUE
            storedValue = cmds.getAttr("{0}.{1}".format(self.storeNode,attr[1]))

            if storedValue in menus:
                command = 'cmds.optionMenu({2},e=1,v=cmds.getAttr("{0}.{1}"))'.format(self.storeNode,attr[1],attr[0])
                print command
                exec(command)
            else:
                #get current option value
                cmd = 'currentValue = cmds.optionMenu({0},q=1,v=1)'.format(attr[0])
                exec(cmd)
                cmds.setAttr(self.storeNode+"."+attr[1],currentValue,type="string")
        

    def fileName(self,**param):

        fromFile = param["fromFile"] if "fromFile" in param else 0
        fromScene = param["fromScene"] if "fromScene" in param else 0
        fromInput = param["fromInput"] if "fromInput" in param else 0

        sortedPlayblastFiles = self.listPlayblasts()
        index = '%04d' %cmds.intField(self.version_input,q=1,value=1) if fromInput else '%04d' %self.getLastIndex()
        raw_name = self.raw_name
        sufix = self.plablastSufix

        newName = self.raw_name + self.plablastSufix + index

        if fromScene:
            name = cmds.getAttr(self.storeNode+".basename") if cmds.getAttr(self.storeNode+".basename") != "" else self.raw_name
            cmds.setAttr(self.storeNode+".basename",name,type="string")
            return name

        elif fromFile:
            name= self.raw_name
            return name
        
        elif fromInput:
            name = cmds.textField(self.basename_input,q=1,text=1) 
            cmds.setAttr(self.storeNode+".basename",name,type="string")
            return name + self.plablastSufix + index
        else:
            return newName

    def getFileName(self,*args):
        name = self.fileName(fromFile=1)
        cmds.textField(self.basename_input,e=1,text=name)

    def nextIndex(self,*args):
        index =  cmds.intField(self.version_input,q=1,v=1)
        cmds.intField(self.version_input,e=1,v=index+1)

    def playblastManagerNode(self,storeNode,**param):

        reset = param["reset"] if "reset" in param else 0

        self.attrLists()

        if reset:
            try:cmds.delete(storeNode)
            except:pass

        if not cmds.objExists(storeNode):
            cmds.createNode('script',ss=True, n=storeNode)

        # text attributes
        nodeCurrentAttrs = cmds.listAttr(storeNode,ud=1) if not cmds.listAttr(storeNode,ud=1) == None else []

        for a in self.textAttrs + self.optAttrs:
            if not a[1] in nodeCurrentAttrs:
                cmds.addAttr(storeNode, ln = a[1], h=False, dt="string")
                cmds.setAttr(storeNode + "." + a[1], a[2] , type="string")

        #int attributes
        numericAttrs = self.checkAttrs + self.intAttrs

        for a in numericAttrs:
            if not a[1] in nodeCurrentAttrs:
                cmds.addAttr(storeNode, ln = a[1], h=False, at="long")
                cmds.setAttr(storeNode + "." + a[1], a[2])

        #no UI Attrs     
        textNoUIAttrs = self.textNoUIAttrs

        for a in textNoUIAttrs:
            if not a in nodeCurrentAttrs:
                cmds.addAttr(storeNode, ln = a, h=False, dt="string")
                cmds.setAttr(storeNode + "." + a, "",type="string")


    def getSceneInfo(self,**param):
        width = param["w"] if "w" in param else 0
        height = param["h"] if "h" in param else 0
        sceneStart = param["sceneStart"] if "sceneStart" in param else 0
        sceneEnd = param["sceneEnd"] if "sceneEnd" in param else 0
        timesliderStart = param["timesliderStart"] if "timesliderStart" in param else 0
        timesliderEnd = param["timesliderEnd"] if "timesliderEnd" in param else 0


        w= cmds.getAttr("defaultResolution.width")
        h= cmds.getAttr("defaultResolution.height")

        se = cmds.playbackOptions( q=1,aet=1)
        ss = cmds.playbackOptions( q=1,ast=1)

        tss = cmds.playbackOptions(q=1,minTime=1)
        tse = cmds.playbackOptions(q=1 , maxTime=1)

        if width: return w
        if height: return h
        if sceneStart: return ss
        if sceneEnd: return se
        if timesliderStart: return tss
        if timesliderEnd: return tse

 
        #cmds.setAttr("defaultResolution.deviceAspectRatio",1.778)
        #cmds.setAttr("defaultResolution.pixelAspect",0.774)

    def setRangeFields(self,*args,**param):
        current=    param ["current"] if "current" in param else 0
        fromData =  param ["fromData"] if "fromData" in param else 0

        if current:
            s = self.getSceneInfo(timesliderStart=1)
            e = self.getSceneInfo(timesliderEnd=1)
        elif fromData:
            s = cmds.getAttr(self.storeNode+".start")
            e = cmds.getAttr(self.storeNode+".end")
        else:
            s = self.getSceneInfo(sceneStart=1)
            e = self.getSceneInfo(sceneEnd=1)

        cmds.intField(self.start_input,e=1,v=s)
        cmds.intField(self.end_input,e=1,v=e)
        self.saveDATA()

    def setResolutionFields(self,*args):

        w = self.getSceneInfo(w=1)
        h = self.getSceneInfo(h=1)
        cmds.intField(self.w_input,e=1,v=w)
        cmds.intField(self.h_input,e=1,v=h)
        
    def setCompressionField(self,*args):
        if not cmds.getAttr(self.storeNode+".compression"):
            cmds.intField(self.compress_input,e=1,v=75)


    def listCams(self,*args):
        cams = cmds.ls(ca=1)
        cams.remove('frontShape')
        cams.remove('sideShape')
        cams.remove('topShape')
        return cams
        
    def blast(self,*args):

        self.getLastIndex(updateField=1)

        #plablast parameters:
        self.pFormat = "qt" if "qt" in pm.mel.eval('playblast -format "{0}" -q;'.format('qt')) else "movie" #avi, qt
        self.pName = self.fileName(fromInput=1)
        self.minT = cmds.intField(self.start_input,q=1,v=1)
        self.maxT = cmds.intField(self.end_input,q=1,v=1)
        self.customMin = self.minT
        self.customMax = self.maxT
        self.saveToFolder = self.playblastPath
        self.showOrnaments = cmds.checkBox(self.ckb_hud,q=1,v=1)
        self.quality = 90
        self.percentOfSize = 100
        self.availableCompressions = cmds.playblast( q=1,compression=1) # Result: [u'IYUV codec', u'MS-RLE', u'MS-CRAM', u'MS-YUV', u'Toshiba YUV411', u'none'] # 
        self.compression = "MS-CRAM"
        self.framePadding = 4
        self.offScreen = 1
        self.w = cmds.intField(self.w_input,q=1,v=1)
        self.h = cmds.intField(self.h_input,q=1,v=1)   
        self.shadows = cmds.checkBox(self.ckb_shadows,q=1,v=1)
        self.resGate = 0
        self.safeArea = 0
        self.safeTitle = 0
        self.filmGate = 0
        self.gateMask = 0
        self.fieldChart =0 
        self.viewport2 = cmds.checkBox(self.ckb_vp20,q=1,v=1)
        self.fog = cmds.checkBox(self.ckb_fog,q=1,v=1)
        self.displayLights = "default" if not cmds.checkBox(self.ckb_lights,q=1,v=1) else "all" #"default";"flat";"all"
        self.size = [self.w,self.h]
        self.AO = cmds.checkBox(self.ckb_ao,q=1,v=1)
        self.antialiasing = cmds.checkBox(self.ckb_antialiasing,q=1,v=1)
        self.panzoom = cmds.checkBox(self.ckb_panzom,q=1,v=1)
        self.locators = cmds.checkBox(self.ckb_locators,q=1,v=1)
        self.wireframeOnShaded = cmds.checkBox(self.ckb_wireframeOnShaded,q=1,v=1)
        self.textures = cmds.checkBox(self.ckb_textures,q=1,v=1) 
        self.flatShaded = cmds.checkBox(self.ckb_flatShaded,q=1,v=1) 
        self.showSelected = cmds.checkBox(self.ckb_showSelected,q=1,v=1) 
        self.imagePlane = cmds.checkBox(self.ckb_imagePlane,q=1,v=1)

        self.generateMP4 = cmds.checkBox(self.ckb_generatecompressed,q=1,v=1)
             
        #extension 
        sys = self.checkOS()
        if (self.pFormat == "qt"):
            self.ext=".mov"
        elif (self.pFormat == "avi"):
            self.ext=".avi"
        elif (self.pFormat == "movie"):
            if sys == "win":
                self.ext=".avi"
            else:
                self.ext=".mov"


        #audio
        gPlayBackSlider = mel.eval( '$tmpVar=$gPlayBackSlider' )
        self.audio = cmds.timeControl( gPlayBackSlider, q=1, sound=1)
               
        #camera
        self.camShape = cmds.optionMenu(self.camera_dropdown,q=1,v=1)
        
        #create window and populate self.playblstPanel
        self.createWin()
        
        self.createMovie()

        if self.pb != None:
            self.seeMovie()
            self.turnOffHeavySuff()
            self.lastMovie(record=1)
            self.saveDATA()
            if self.generateMP4:
                #self.handbrake()
                self.ffMpegCompress()
            SF.autoSaveRoutine(folder = self.playblastPath, fileName=self.pName)
            self.nextIndex()
        self.deleteWin()

    def createWin(self):
        self.pbViewportWin = "temp_pbWin"

        #delete existing window
        if cmds.window(self.pbViewportWin,ex=1):
            print "recreating temp window for plablast."
            cmds.deleteUI(self.pbViewportWin,window=1)

        self.pbViewportWin=cmds.window(self.pbViewportWin)
        layout = cmds.paneLayout()
               
        self.playblstPanel = cmds.modelPanel(l="playblast_temp",cam=self.camShape)

        cmds.modelEditor(self.playblstPanel,e=1,
            grid=0,
            nurbsCurves=0,
            polymeshes=1,
            locators=self.locators,
            lights=0,
            joints=0,
            handles=0,
            dimensions=0,
            deformers=0,
            cameras=0,
            imagePlane=self.imagePlane,
            displayAppearance="smoothShaded" if not self.flatShaded else "flatShaded",
            wireframeOnShaded= self.wireframeOnShaded,
            displayTextures=self.textures,
            displayLights=self.displayLights)
        
        cmds.showWindow(self.pbViewportWin)
        cmds.setFocus(self.playblstPanel)

        #viewport 2.0
        if self.viewport2:
            cmds.modelEditor(self.playblstPanel, e= 1, rendererName = "vp2Renderer")
        else:
            cmds.modelEditor(self.playblstPanel, e= 1, rendererName = "base_OpenGL_Renderer")                
        #fog
        cmds.modelEditor(self.playblstPanel,e=1,fogging=self.fog)      
        #light
        cmds.modelEditor(self.playblstPanel,e=1,dl=self.displayLights)    
        #hide selection and manipulator
        cmds.modelEditor(self.playblstPanel,e=1,sel= self.showSelected ,manipulators=0)
        
        #resetpanzoom
        self.currentPanzoom = cmds.getAttr(self.camShape+".panZoomEnabled")
        if not self.panzoom:
            cmds.setAttr(self.camShape+".panZoomEnabled",0)
         
   
        #hiquality
        cmds.setAttr("hardwareRenderingGlobals.ssaoEnable", self.AO)
        if not cmds.getAttr("hardwareRenderingGlobals.ssaoAmount"): 
            cmds.setAttr("hardwareRenderingGlobals.ssaoAmount", 1.5)
        cmds.setAttr("hardwareRenderingGlobals.multiSampleEnable", self.antialiasing)
        cmds.setAttr("hardwareRenderingGlobals.transparencyQuality", 1) #best is  1
        cmds.modelEditor(self.playblstPanel, e= 1, shadows = self.shadows)
            
        #resulitiongate
        self.origResGate = cmds.getAttr(self.camShape+".displayResolution")
        self.origOverscan = cmds.getAttr(self.camShape+".overscan")
        self.origSafeArea = cmds.getAttr(self.camShape+".displaySafeAction")
        self.origSafeTitle = cmds.getAttr(self.camShape+".displaySafeTitle")
        self.origFilmGate = cmds.getAttr(self.camShape+".displayFilmGate")
        self.origGateMask = cmds.getAttr(self.camShape+".displayGateMask")
        self.origFieldChart = cmds.getAttr(self.camShape+".displayFieldChart")
        self.origFilmFit = cmds.getAttr(self.camShape+".filmFit")
        
        
        self.camAttrs =     [[self.camShape+".displayResolution" ,  self.resGate,           self.origResGate],
                            [self.camShape+".overscan" ,            1 ,                     self.origOverscan],
                            [self.camShape+".displaySafeAction" ,   self.safeArea ,         self.origSafeArea],
                            [self.camShape+".displaySafeTitle" ,    self.safeTitle ,        self.origSafeTitle],
                            [self.camShape+".displayFilmGate" ,     self.filmGate ,         self.origFilmGate ],
                            [self.camShape+".displayGateMask" ,     self.gateMask ,         self.origGateMask],
                            [self.camShape+".displayFieldChart" ,   self.fieldChart ,       self.origFieldChart ],
                            [self.camShape+".filmFit"           ,   1 ,                     self.origFilmFit ]]

        for c in self.camAttrs:
            if not cmds.getAttr(c[0],l=1) and  cmds.listConnections(c[0]) == None: 
                cmds.setAttr(c[0],c[1])
        
        cmds.refresh(force=1)
        
    def turnOffHeavySuff(self):
        cmds.modelEditor(self.playblstPanel,e=1,fogging=0)
        cmds.modelEditor(self.playblstPanel,e=1,dl="default") 
        cmds.setAttr("hardwareRenderingGlobals.ssaoEnable", 0)
        cmds.setAttr("hardwareRenderingGlobals.multiSampleEnable", 0)
        cmds.modelEditor(self.playblstPanel, e= 1, shadows = 0)

    def deleteWin(self,*args):
        #delete temp window

        cmds.deleteUI(self.pbViewportWin,window=1)

    def createMovie(self,*args):

        #BLAST!!
        print "\n:::::::::::::::::::\n"+self.pName+" is Playblasting! :D ... go grab a cofee..."+"\n:::::::::::::::::::\n"
        
        self.pb = cmds.playblast( format = self.pFormat,
            forceOverwrite=1, 
            w=self.w, 
            h=self.h, 
            st=self.customMin, 
            et=self.customMax, 
            filename = self.saveToFolder+"/"+ self.pName, 
            clearCache = 1, 
            viewer = 0,
            s=self.audio, 
            showOrnaments = self.showOrnaments, 
            fp = self.framePadding, 
            percent = self.percentOfSize, 
            qlt = self.quality, 
            compression = self.compression,
            os = self.offScreen)
            
        
        try:
            print "\n:::::::::::::::::::\n"+self.pb+"\n:::::::::::::::::::\n"
        except:
            pass
        
        #reset camera
        for c in self.camAttrs:
            if not cmds.getAttr(c[0],l=1) and  cmds.listConnections(c[0]) == None: 
                cmds.setAttr(c[0],c[2])
        #resetPanzoom
        cmds.setAttr(self.camShape+".panZoomEnabled",self.currentPanzoom)
        
    def lastMovie(self,**param):

        record = param["record"] if "record" in param else 0

        if record:
            playblast = self.playblastPath+"/"+self.listPlayblasts()[-1] if len(self.listPlayblasts()) else ""
            cmds.setAttr(self.storeNode+".lastPlayblast",playblast,type="string")
        else:
            playblast = cmds.getAttr(self.storeNode+".lastPlayblast")

        return playblast

    def toggleColorManagement(self,*args):

        cm = not cmds.colorManagementPrefs(q=True,cme=1)
        cmBlast = not cmds.colorManagementPrefs(q=True,ote=1,ott="playblast")

        cmds.colorManagementPrefs(e=True,cme=cm)
        cmds.colorManagementPrefs(e=True,ote=cm ,ott="playblast")

        if cm:
            cmds.warning("color management OFF")
        else:
            cmds.warning("color management ON")

    def handbrake(self,*args,**param):

        input = self.playblastPath+"/"+self.listPlayblasts()[-1] if len(self.listPlayblasts()) else 0
        output = self.apresentPath+"/"+self.fileName(fromInput=1)+".mp4"
        quality = 25

        os.system(self.handBrakePath + ' -f av_mp4 -e x264 -q '+str(quality)+' --encoder-preset superfast -2 --two-pass -b --bv 3200 -i '+input+' -o '+output)

    def ffMpegCompress(self,*args,**param):

        input = self.playblastPath+"/"+self.listPlayblasts()[-1] if len(self.listPlayblasts()) else 0
        output = self.apresentPath+"/"+self.fileName(fromInput=1)+".mp4"
        quality = 100 - cmds.intField(self.compress_input,q=1,v=1)

        if input:
            stream = ffmpeg.input(input)
            #stream = ffmpeg.hflip(stream)
            stream = ffmpeg.output(stream, output ,crf=quality)
            stream= ffmpeg.overwrite_output(stream)
            ffmpeg.run(stream)

    def seeMovie(self,*args):
        cmds.launch(movie=self.pb + self.ext)

    def seeLastMovie(self,*args):
        movie = self.lastMovie()
        cmds.launch(movie=movie)

    def openFolder(self,*args):
        folder = self.playblastPath+"/"
        print folder
        #subprocess.call('explorer "'+folder+'"', shell=True)
        subprocess.Popen(r'explorer /select,"'+folder.replace("/","\\")+'"')
        #os.system('explorer /select,"'+folder+'"')

    def toggleFrameNumber(self,*args):

        if cmds.headsUpDisplay( 'HUDFrameNum',ex=1):
            cmds.headsUpDisplay( 'HUDFrameNum', rem=1 )
            mel.eval("""
                    optionVar -iv fontSetOpt 0; 
                    displayPref -fm 0;
                    savePrefsChanges;""") #set hud font size to default
        else:
            cmds.headsUpDisplay("HUDFrameNum",section=8,
                                block =1,
                                blockSize="large",
                                command="cmds.currentTime(q=1)",
                                decimalPrecision=2,
                                dataFontSize="large",
                                dataAlignment="right",
                                attachToRefresh=1,
                                vis=1)
            
            allHuds = cmds.headsUpDisplay( lh=1)
            hudToShow= ['HUDFrameNum']#"HUDCurrentFrame"]
            
            for hud in allHuds:
                vis = 1 if hud in hudToShow else 0   
                cmds.headsUpDisplay( hud, e=1, vis=vis )

            mel.eval("""
                    optionVar -iv fontSetOpt 2; 
                    displayPref -fm 2;
                    displayPref -sfs 12;
                    displayPref -dfs 16;
                    savePrefsChanges;""")#set hud font size to biggest possible



    def UI(self): 
    
        self.pbWin = "playblastManager"
        
        if (cmds.window(self.pbWin, exists=True)):
            cmds.deleteUI(self.pbWin)
        
        cmds.window(self.pbWin,w=600)   
        self.Layout = cmds.formLayout()

        #labels
        self.basename_lb = cmds.text(label="basename:")
        self.folder_lb = cmds.text(label="folder:")    
        self.w_lb = cmds.text(label="W")  
        self.h_lb = cmds.text(label="H") 
        self.version_lb = cmds.text(label="version:") 
        self.range_lb = cmds.text(label="range:") 
        self.s_lb = cmds.text(label="S") 
        self.e_lb = cmds.text(label="E") 


        #buttons
        self.next_bt = cmds.button(label="next",h=18,c=partial(self.nextIndex))
        self.filename_bt = cmds.button(label="file name",h=18,c=partial(self.getFileName))
        self.choose_bt = cmds.button(label="choose",h=18,c=partial(self.getFolder))
        self.history_bt = cmds.button(label="open folder",h=20,w=80,c=partial(self.openFolder))
        self.openlast_bt = cmds.button(label="open last",h=20,w=80,c=partial(self.seeLastMovie))
        self.playblast_bt = cmds.button(label="plablast!",h=25,w=100,c=partial(self.blast))
        self.currentrange_bt = cmds.button(label="current",h=18,c=partial(self.setRangeFields,current=1))
        self.fullrange_bt = cmds.button(label="full",h=18,c=partial(self.setRangeFields))
        self.getRes_bt = cmds.button(label="get RES",h=18,c=partial(self.setResolutionFields))
        self.toggleCM_bt = cmds.button(label="color management",h=20,c=partial(self.toggleColorManagement))
        self.toggleFrameNumber_bt = cmds.button(label="display frame number", h=20, c=partial(self.toggleFrameNumber))

        
        #check boxes
        self.ckb_vp20 = cmds.checkBox(label="vp2.0",v=1,cc=partial(self.saveDATA))
        self.ckb_hud = cmds.checkBox(label="hud extras",cc=partial(self.saveDATA))
        self.ckb_ao = cmds.checkBox(label="ambient occlusion",v=1,cc=partial(self.saveDATA))
        self.ckb_lights = cmds.checkBox(label="lights",cc=partial(self.saveDATA))  
        self.ckb_antialiasing = cmds.checkBox(label="anti-aliasing",v=1,cc=partial(self.saveDATA))
        self.ckb_generatecompressed = cmds.checkBox(label="compressed version mp4",cc=partial(self.saveDATA))  
        self.ckb_panzom = cmds.checkBox(label="2d panZoom",cc=partial(self.saveDATA)) 
        self.ckb_locators = cmds.checkBox(label="locators",cc=partial(self.saveDATA))
        self.ckb_wireframeOnShaded = cmds.checkBox(label="wireframe shaded",cc=partial(self.saveDATA))
        self.ckb_textures = cmds.checkBox(label="textures",v=1,cc=partial(self.saveDATA))
        self.ckb_shadows= cmds.checkBox(label="shadows",cc=partial(self.saveDATA))
        self.ckb_fog = cmds.checkBox(label="fog",cc=partial(self.saveDATA))
        self.ckb_flatShaded = cmds.checkBox(label="flat shaded",cc=partial(self.saveDATA))
        self.ckb_showSelected = cmds.checkBox(label="selection highlighting",cc=partial(self.saveDATA))
        self.ckb_imagePlane = cmds.checkBox(label="image planes",cc=partial(self.saveDATA))
        

        #input fields
        self.basename_input = cmds.textField(text=self.fileName(fromScene=1),w=200,cc=partial(self.saveDATA))
        self.version_input = cmds.intField( minValue= self.getLastIndex() , step=1 ,w=60,value= self.getLastIndex(),cc=partial(self.saveDATA))
        self.folder_input = cmds.textField(text=self.playblastPath,w=300,cc=partial(self.saveDATA))
        self.w_input = cmds.intField(v=self.getSceneInfo(w=1),w=50,cc=partial(self.saveDATA))
        self.h_input = cmds.intField(v=self.getSceneInfo(h=1),w=50,cc=partial(self.saveDATA))
        self.start_input = cmds.intField(v=self.getSceneInfo(sceneStart=1),w=50,cc=partial(self.saveDATA))
        self.end_input = cmds.intField(v=self.getSceneInfo(sceneEnd=1),w=50,cc=partial(self.saveDATA))
        self.compress_input = cmds.intField(v=75,minValue=0,maxValue= 100,w=50,cc=partial(self.saveDATA))

        #separator
        self.separator01 = cmds.separator(w=560)
        self.separator02 = cmds.separator(w=560)
        self.separator03 = cmds.separator(w=560)
        self.separator04 = cmds.separator(w=560)
        self.separator05 = cmds.separator(w=560)

        #dropdown

        self.camera_dropdown = cmds.optionMenu( label='camera:', changeCommand=partial(self.saveDATA),w=350 )
        cams = self.listCams()
        for c in cams:
            cmds.menuItem( label=c ,p=self.camera_dropdown)


        #partial(self.fillNameID)

        line01 = 5
        line02 = 30
        line03 = 50
        line04 = 65
        line045 = 88
        line05 = 95 
        line055 = 120       
        line06 = 130
        line07 = 210
        line08 = 215
        line09 = 235
        line10 = 245

        column01 = 5
        column02 = 150
        column03 = 305

        cmds.formLayout(self.Layout, e=1, attachForm=[
                    (self.basename_lb,"top",line01),
                    (self.basename_lb,"left",5),
                    (self.basename_input,"top",line01),
                    (self.basename_input,"left",65),
                    (self.filename_bt,"top",line01),
                    (self.filename_bt,"left",265),

                    (self.version_lb,"top",line01),
                    (self.version_lb,"left",410),
                    (self.version_input,"top",line01),
                    (self.version_input,"left",460),
                    (self.next_bt,"top",line01),
                    (self.next_bt,"left",520),

                    (self.folder_lb,"top",line02),
                    (self.folder_lb,"left",5),
                    (self.folder_input,"top",line02),
                    (self.folder_input,"left",65),
                    (self.choose_bt,"top",line02),
                    (self.choose_bt,"left",365),

                    (self.separator01,"top",line03+5),
                    (self.separator01,"left",5),

                    (self.camera_dropdown,"top",line04),
                    (self.camera_dropdown,"left",5),
                    (self.w_lb,"top",line04),
                    (self.w_lb,"left",380),
                    (self.w_input,"top",line04),
                    (self.w_input,"left",393),
                    (self.h_lb,"top",line04),
                    (self.h_lb,"left",450),
                    (self.h_input,"top",line04),
                    (self.h_input,"left",460),
                    (self.getRes_bt,"top",line04),
                    (self.getRes_bt,"left",510),

                    (self.separator02,"top",line045),
                    (self.separator02,"left",5),

                    (self.range_lb,"top",line05),
                    (self.range_lb,"left",5),
                    (self.s_lb,"top",line05),
                    (self.s_lb,"left",50),
                    (self.start_input,"top",line05),
                    (self.start_input,"left",60),
                    (self.e_lb,"top",line05),
                    (self.e_lb,"left",120),
                    (self.end_input,"top",line05),
                    (self.end_input,"left",130),
                    (self.currentrange_bt,"top",line05),
                    (self.currentrange_bt,"left",190),
                    (self.fullrange_bt,"top",line05),
                    (self.fullrange_bt,"left",250),
                    (self.toggleFrameNumber_bt,"top",line05),
                    (self.toggleFrameNumber_bt,"left",430),

                    (self.separator03,"top",line055),
                    (self.separator03,"left",5),



                    (self.ckb_vp20,"top",line06),
                    (self.ckb_vp20,"left",column01),
                    (self.ckb_lights,"top",line06+15),
                    (self.ckb_lights,"left",column01),
                    (self.ckb_hud,"top",line06+30),
                    (self.ckb_hud,"left",column01),
                    (self.ckb_ao,"top",line06+45),
                    (self.ckb_ao,"left",column01),
                    (self.ckb_antialiasing,"top",line06+60),
                    (self.ckb_antialiasing,"left",column01),
                    

                    
                    (self.ckb_panzom,"top",line06),
                    (self.ckb_panzom,"left",column02),
                    (self.ckb_locators,"top",line06+15),
                    (self.ckb_locators,"left",column02),
                    (self.ckb_wireframeOnShaded,"top",line06+30),
                    (self.ckb_wireframeOnShaded,"left",column02),
                    (self.ckb_textures,"top",line06+45),
                    (self.ckb_textures,"left",column02),
                    (self.ckb_shadows,"top",line06+60),
                    (self.ckb_shadows,"left",column02),

                    
                    (self.ckb_fog,"top",line06),
                    (self.ckb_fog,"left",column03),
                    (self.ckb_flatShaded,"top",line06+15),
                    (self.ckb_flatShaded,"left",column03),
                    (self.ckb_showSelected,"top",line06+30),
                    (self.ckb_showSelected,"left",column03),
                    (self.ckb_imagePlane,"top",line06+45),
                    (self.ckb_imagePlane,"left",column03),



                    (self.separator04,"top",line07),
                    (self.separator04,"left",5),

                    (self.ckb_generatecompressed,"top",line08),
                    (self.ckb_generatecompressed,"left",column01),
                    (self.compress_input,"top",line08),
                    (self.compress_input,"left",column02),
                    
                    (self.separator05,"top",line09),
                    (self.separator05,"left",5),

                    (self.history_bt,"top",line10),
                    (self.history_bt,"left",5),
                    (self.openlast_bt,"top",line10),
                    (self.openlast_bt,"left",90),
                    (self.toggleCM_bt,"top",line10),
                    (self.toggleCM_bt,"left",230),
                    (self.playblast_bt,"top",line10),
                    (self.playblast_bt,"left",450)])
                    
          
        cmds.showWindow(self.pbWin)
        cmds.evalDeferred("cmds.window(\""+self.pbWin+"\",edit=1,w=570,h=280)")
        self.readDATA()
        self.setRangeFields(fromData=1)
        self.setResolutionFields()
        self.setCompressionField()

        
           

        cmds.scriptJob(event=["SceneOpened",partial(self.load)],p=self.pbWin)
        
p=PlayblastManager()