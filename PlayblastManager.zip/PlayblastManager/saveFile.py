import maya.cmds as cmds
import os
from functools import partial
import datetime

#for listFilesSortedByDate function
from stat import S_ISREG, ST_CTIME, ST_MODE
import sys, time


class Save:
    def __init__(self):
        self.id= id(self)
        self.autoSaveInterval = 600 #in seconds
        self.tempDir = cmds.internalVar(userTmpDir=1)
        self.maximunAutoSaveFiles = 50

    def listFilesSortedByDate(self,givenPath):

        # path to the directory (relative or absolute)
        #dirpath = sys.argv[1] if len(sys.argv) == 2 else r'.'
        dirpath = givenPath

        dirStuff = os.listdir(dirpath)

        if dirStuff:
            # get all entries in the directory w/ stats
            entries = (os.path.join(dirpath, fn) for fn in dirStuff)
            entries = ((os.stat(path), path) for path in entries)

            # leave only regular files, insert creation date
            entries = ((stat[ST_CTIME], path)
                       for stat, path in entries if S_ISREG(stat[ST_MODE]))
            #NOTE: on Windows `ST_CTIME` is a creation date 
            #  but on Unix it could be something else
            #NOTE: use `ST_MTIME` to sort by a modification date
            sortedFiles = []
            for cdate, path in sorted(entries):
                if ".mb" in path or ".ma" in path:
                    sortedFiles.append(os.path.basename(path))
                    #print time.ctime(cdate), os.path.basename(path)

            return sortedFiles
                      
    def autoSaveRoutine(self,**param):
        #vars   
        originaName = cmds.file(q=1,sn=1)

        folder   = param["folder"] if "folder" in param else cmds.file(q=1,sn=1)
        filename = param["fileName"] if "fileName" in param else os.path.basename(originaName)

        extension = os.path.splitext(filename)[-1]
        
        autoSavePath = folder+"/"
              
        #list autosavefiles
            
        dir_stuff=os.listdir(autoSavePath)
        
        autosaveFiles = [ f for f in dir_stuff if os.path.isfile(os.path.join(autoSavePath,f)) and (".mb" in f or ".ma" in f)]
        sortedAutoSaveFiles = self.listFilesSortedByDate(autoSavePath)

        #if there is some file saved
        if autosaveFiles:
            #keep maximun number of autosave files
            if len(autosaveFiles) >= self.maximunAutoSaveFiles:
                #print sortedAutoSaveFiles[0]
                cmds.sysFile( os.path.join(autoSavePath,sortedAutoSaveFiles[0]) , delete=True )
      

        #save as the neew temp name
        cmds.file(rename = autoSavePath+filename+extension)
        cmds.file(f=1,save=1,options="v=0;p=17;f=0")
        

        #rename back to our initial name
        cmds.file(rename = originaName)
        print "file "+ filename + " auto Saved: ",autoSavePath+filename+extension,"\nat ",datetime.datetime.now()
        #cmds.warning("File auto Saved at "+autoSavePath+" ---- "       +str(datetime.datetime.now()))
        #cmds.inViewMessage(smg="File auto Saved at <hl>"+autoSavePath+"</hl> !",bkc="0x00000000",fade=1,fts=12,pos="midCenter")

