
import maya.cmds as cmds
import maya.mel as mel
import os
import sys

#to be able to import scirpts in same folder of this one
script_path = os.path.dirname(os.path.abspath( __file__ ))
if not script_path in sys.path: sys.path.append(script_path)

def onMayaDroppedPythonFile(*args, **kwargs):
    pass

def installButton():


    annotation = "Playblast manager"
    label = 'PBManager'
    image = "playblast.png"
    command = "import maya.cmds as cmds\nimport os\nimport sys\nif not '{0}' in sys.path: sys.path.append('{0}')\nimport playblastManager\nreload(playblastManager)".format(script_path)

    found=0
    currShelf = mel.eval('$gShelfTopLevel=$gShelfTopLevel')
    currTab = cmds.tabLayout(currShelf, q=1, selectTab=1)
    shelfButtons = cmds.shelfLayout(currTab, q=1, childArray=1)


    if shelfButtons != None:
        
        for bt in shelfButtons:
            currLabel = cmds.shelfButton(bt, q=True, label=True)
            if label == currLabel:
                found = 1
                
                button = bt



    if found:
        cmds.shelfButton(   button, e=1,
                            annotation=annotation,
                            label=label,
                            image1=image,
                            command=command,
                            stp="python",w=15,h=40)
    else:
        cmds.shelfButton(   annotation=annotation,
                            label=label,
                            image1=image,
                            command=command,
                            parent=currTab,
                            stp="python",w=15,h=40)

onMayaDroppedPythonFile()
installButton()