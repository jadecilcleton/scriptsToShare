import maya.cmds as cmds
import os
from functools import partial
import datetime

#for listFilesSortedByDate function
from stat import S_ISREG, ST_CTIME, ST_MODE
import sys, time


class Save:
    def __init__(self):
        self.id= id(self)
        self.autoSaveInterval = 600 #in seconds
        self.tempDir = cmds.internalVar(userTmpDir=1)
        self.maximunAutoSaveFiles = 30

    def listFilesSortedByDate(self,givenPath):

        # path to the directory (relative or absolute)
        #dirpath = sys.argv[1] if len(sys.argv) == 2 else r'.'
        dirpath = givenPath

        dirStuff = os.listdir(dirpath)

        if dirStuff:
            # get all entries in the directory w/ stats
            entries = (os.path.join(dirpath, fn) for fn in dirStuff)
            entries = ((os.stat(path), path) for path in entries)

            # leave only regular files, insert creation date
            entries = ((stat[ST_CTIME], path)
                       for stat, path in entries if S_ISREG(stat[ST_MODE]))
            #NOTE: on Windows `ST_CTIME` is a creation date 
            #  but on Unix it could be something else
            #NOTE: use `ST_MTIME` to sort by a modification date
            sortedFiles = []
            for cdate, path in sorted(entries):
                sortedFiles.append(os.path.basename(path))
                #print time.ctime(cdate), os.path.basename(path)

            return sortedFiles
                      
    def autoSaveRoutine(self):
        #vars   
        fullpath = cmds.file(q=1,sn=1)
        filename = os.path.basename(fullpath)
        filepath = fullpath.replace(filename,"")
        raw_name, extension = os.path.splitext(filename)
        
        autSaveSufix ="_bAutoSave_"
        autoSavePath = self.tempDir+"_bAutosave/"
        
        #create autosave folder
        if not os.path.exists(autoSavePath):
            os.makedirs(autoSavePath)
        
        #list autosavefiles
            
        dir_stuff=os.listdir(autoSavePath)
        
        autosaveFiles = [ f for f in dir_stuff if os.path.isfile(os.path.join(autoSavePath,f)) and autSaveSufix in f ]
        sortedAutoSaveFiles = self.listFilesSortedByDate(autoSavePath)

        #if there is some file saved
        if autosaveFiles:
            #keep maximun number of autosave files
            if len(autosaveFiles) >= self.maximunAutoSaveFiles:
                #print sortedAutoSaveFiles[0]
                cmds.sysFile( os.path.join(autoSavePath,sortedAutoSaveFiles[0]) , delete=True )

            #get last index
            autoSaveFromThisFile = []
            for f in autosaveFiles:
                #listing autosave from current file
                if raw_name == f.split(autSaveSufix)[0]:
                    autoSaveFromThisFile.append(f)

            #if there is already autosave from current file  
            if len(autoSaveFromThisFile):
                lastIndex = int(os.path.splitext(autoSaveFromThisFile[-1])[0].split(autSaveSufix)[-1])
                newIndex = '%04d' % (lastIndex + 0001)
                #build new name incrementing the index
                newName = raw_name + autSaveSufix + newIndex
            else:
                #if there is no autosave from current file 
                #build new name for first autoSave for this file
                newName = raw_name + autSaveSufix + "0001"
        else:
            #new name for the first autosave file inside the directory
            newName = raw_name + autSaveSufix + "0001"
        

        #save as the neew temp name
        cmds.file(rename = autoSavePath+newName+extension)
        cmds.file(f=1,save=1,options="v=0;p=17;f=0")
        

        #rename back to our initial name
        cmds.file(rename = fullpath)
        print "file "+ raw_name + " auto Saved: ",autoSavePath+newName+extension,"\nat ",datetime.datetime.now()
        #cmds.warning("File auto Saved at "+autoSavePath+" ---- "       +str(datetime.datetime.now()))
        #cmds.inViewMessage(smg="File auto Saved at <hl>"+autoSavePath+"</hl> !",bkc="0x00000000",fade=1,fts=12,pos="midCenter")

